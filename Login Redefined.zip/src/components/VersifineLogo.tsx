type Props = {
  className?: string;
  title?: string;
};

/**
 * Versifine wordmark recreated as inline SVG.
 * Uses currentColor so the parent can theme it (white on dark, navy on light).
 * The custom "V" mark is drawn as a path; "ersifine" is set in Outfit
 * (already loaded globally) to closely match the rounded geometric original.
 */
export function VersifineLogo({ className, title = "Versifine" }: Props) {
  return (
    <svg
      viewBox="0 0 520 140"
      className={className}
      role="img"
      aria-label={title}
      fill="currentColor"
      xmlns="http://www.w3.org/2000/svg"
    >
      <title>{title}</title>
      {/* Custom V mark — chunky, rounded corners, slight right-cap flare */}
      <path
        d="M14 18
           Q14 10 22 10
           L52 10
           Q58 10 60.8 15.4
           L84 62
           L107.2 15.4
           Q110 10 116 10
           L138 10
           Q146 10 146 18
           Q146 21 144.6 23.6
           L96.4 124
           Q93.6 130 87 130
           L81 130
           Q74.4 130 71.6 124
           L15.4 23.6
           Q14 21 14 18 Z"
      />
      {/* Wordmark — Outfit, tracked tight to mimic the source */}
      <text
        x="160"
        y="103"
        fontFamily="Outfit, ui-sans-serif, system-ui, sans-serif"
        fontWeight={600}
        fontSize="118"
        letterSpacing="-4"
      >
        ersifine
      </text>
    </svg>
  );
}
