import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import versifineIcon from "@/assets/versifine-icon.png";
import versifineLogo from "@/assets/versifine-logo.svg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Log in · Versifine" },
      { name: "description", content: "Sign in to your Versifine account." },
    ],
  }),
  component: LoginPage,
});

const ROTATING_WORDS = ["workspace", "dashboard", "account", "studio"];

function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [wordIdx, setWordIdx] = useState(0);

  useEffect(() => {
    const id = setInterval(
      () => setWordIdx((i) => (i + 1) % ROTATING_WORDS.length),
      2600,
    );
    return () => clearInterval(id);
  }, []);


  return (
    <div className="min-h-screen w-full bg-background text-foreground grid lg:grid-cols-2">
      {/* ───────── Left brand panel ───────── */}
      <aside
        className="relative hidden lg:flex flex-col justify-between p-10 xl:p-14 overflow-hidden text-white"
        style={{
          background:
            "linear-gradient(160deg, oklch(0.32 0.18 268) 0%, oklch(0.22 0.16 268) 60%, oklch(0.16 0.12 268) 100%)",
        }}
      >
        {/* Aurora glow blobs */}
        <div
          aria-hidden
          className="absolute -top-40 -left-32 w-[520px] h-[520px] rounded-full pointer-events-none animate-aurora"
          style={{
            background:
              "radial-gradient(closest-side, oklch(0.55 0.22 290 / 0.55), transparent 70%)",
            filter: "blur(40px)",
          }}
        />
        <div
          aria-hidden
          className="absolute top-1/3 -right-24 w-[420px] h-[420px] rounded-full pointer-events-none animate-aurora"
          style={{
            background:
              "radial-gradient(closest-side, oklch(0.6 0.2 230 / 0.45), transparent 70%)",
            filter: "blur(50px)",
            animationDelay: "-7s",
          }}
        />

        {/* Background mark — large faded V (drifts slowly) */}
        <img
          src={versifineIcon}
          alt=""
          aria-hidden
          className="absolute -right-32 -bottom-32 w-[640px] opacity-[0.07] pointer-events-none select-none animate-drift"
        />

        {/* Brand */}
        <a
          href="/"
          className="relative z-10 inline-flex self-start items-center rise-1"
          aria-label="Versifine home"
        >
          <img
            src={versifineLogo}
            alt="Versifine"
            className="h-[22px] w-auto"
            style={{ filter: "brightness(0) invert(1)" }}
          />
        </a>

        {/* Quote */}
        <blockquote className="relative z-10 max-w-md rise-2">
          <p className="text-[22px] leading-[1.5] font-light tracking-[-0.01em] text-white/95">
            Versifine has become the quiet backbone of how our team thinks
            about numbers. It stays out of the way, and that is the highest
            praise we can give a tool.
          </p>
          <footer className="mt-6 text-[13px] text-white/55 flex items-center gap-2">
            <span
              aria-hidden
              className="inline-block w-1.5 h-1.5 rounded-full bg-green-400 animate-livedot"
            />
            <span className="text-white/85 font-medium">Elena Marchetti</span>
            <span className="opacity-50">·</span>
            <span>Head of Design, Cinder</span>
          </footer>
        </blockquote>

        {/* Footer */}
        <div className="relative z-10 flex items-center justify-between text-[12px] text-white/45 rise-3">
          <span>© {new Date().getFullYear()} Versifine, Inc.</span>
          <div className="flex gap-5">
            <a href="#" className="hover:text-white/80 transition-colors">Privacy</a>
            <a href="#" className="hover:text-white/80 transition-colors">Terms</a>
          </div>
        </div>

      </aside>

      {/* ───────── Right form panel ───────── */}
      <main className="relative flex flex-col overflow-hidden">
        {/* Faint dot grid background */}
        <div
          aria-hidden
          className="absolute inset-0 pointer-events-none opacity-60"
          style={{
            backgroundImage:
              "radial-gradient(oklch(0.18 0.005 260 / 0.06) 1px, transparent 1px)",
            backgroundSize: "22px 22px",
            maskImage:
              "radial-gradient(ellipse at 70% 40%, black 0%, transparent 75%)",
          }}
        />
        {/* Huge V bleeding off the top-right edge */}
        <img
          src={versifineIcon}
          alt=""
          aria-hidden
          className="absolute -top-32 -right-40 w-[460px] pointer-events-none select-none animate-drift"
          style={{
            opacity: 0.05,
            transform: "rotate(8deg)",
            animationDelay: "-9s",
          }}
        />

        <header className="relative z-10 flex items-center justify-between px-6 sm:px-10 py-6 rise-1">
          <a href="/" className="flex items-center gap-2 lg:hidden" aria-label="Versifine home">
            <img src={versifineIcon} alt="" className="w-7 h-7" />
            <span className="text-[16px] font-semibold tracking-[-0.02em]">Versifine</span>
          </a>

          <div className="ml-auto text-[13px] text-muted-foreground">
            New to Versifine?{" "}
            <a
              href="#"
              className="font-medium hover:underline underline-offset-4"
              style={{ color: "var(--brand)" }}
            >
              Create an account
            </a>
          </div>
        </header>

        <div className="relative z-10 flex-1 flex items-center justify-center px-6 pb-16">
          <div className="w-full max-w-[380px]">
            <div className="rise-2">
              <h1 className="text-[24px] font-semibold tracking-[-0.02em] flex flex-wrap items-baseline gap-x-1.5">
                <span>Sign in to your</span>
                <span
                  key={wordIdx}
                  className="inline-block animate-[rise_0.5s_ease-out]"
                  style={{ color: "var(--brand)" }}
                >
                  {ROTATING_WORDS[wordIdx]}
                </span>
              </h1>
              <p className="mt-1.5 text-[14px] text-muted-foreground">
                Welcome back. Please enter your details.
              </p>
            </div>




            <div className="mt-8 space-y-2.5 rise-3">
              <SocialButton>
                <GoogleMark />
                <span>Continue with Google</span>
              </SocialButton>
              <SocialButton>
                <AppleMark />
                <span>Continue with Apple</span>
              </SocialButton>
            </div>


            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-border" />
              </div>
              <div className="relative flex justify-center">
                <span className="bg-background px-3 text-[12px] text-muted-foreground">
                  or
                </span>
              </div>
            </div>

            <form onSubmit={(e) => e.preventDefault()} className="space-y-4 rise-4">
              <Field
                label="Email"
                type="email"
                value={email}
                onChange={setEmail}
                placeholder="name@company.com"
                autoComplete="email"
              />
              <Field
                label="Password"
                type="password"
                value={password}
                onChange={setPassword}
                placeholder="Enter your password"
                autoComplete="current-password"
                trailing={
                  <a
                    href="#"
                    className="text-[12px] text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Forgot password?
                  </a>
                }
              />

              <button
                type="submit"
                className="group relative w-full py-2.5 text-[14px] font-medium rounded-md text-white overflow-hidden mt-1 transition-transform active:scale-[0.99]"
                style={{
                  background:
                    "linear-gradient(120deg, var(--brand-deep), var(--brand) 50%, var(--brand-deep))",
                  backgroundSize: "200% 100%",
                  boxShadow:
                    "0 8px 24px -10px color-mix(in oklab, var(--brand) 60%, transparent)",
                }}
              >
                <span className="relative z-10 inline-flex items-center justify-center gap-2">
                  Sign in
                  <span
                    aria-hidden
                    className="transition-transform group-hover:translate-x-0.5"
                  >
                    →
                  </span>
                </span>
                {/* shimmer */}
                <span
                  aria-hidden
                  className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-[1100ms] ease-out"
                  style={{
                    background:
                      "linear-gradient(90deg, transparent, rgba(255,255,255,0.18), transparent)",
                  }}
                />
              </button>

              <div className="flex items-center justify-center gap-1.5 pt-1 text-[11px] text-muted-foreground">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                  <rect x="3" y="11" width="18" height="11" rx="2" />
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                </svg>
                <span>Protected by end-to-end encryption</span>
              </div>

            </form>

            <p className="mt-8 text-center text-[12px] text-muted-foreground">
              By continuing, you agree to our{" "}
              <a href="#" className="text-foreground/80 hover:text-foreground underline-offset-4 hover:underline">
                Terms
              </a>{" "}
              and{" "}
              <a href="#" className="text-foreground/80 hover:text-foreground underline-offset-4 hover:underline">
                Privacy Policy
              </a>
              .
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}

/* ───────── helpers ───────── */

function Field({
  label,
  type,
  value,
  onChange,
  placeholder,
  autoComplete,
  trailing,
}: {
  label: string;
  type: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  autoComplete?: string;
  trailing?: React.ReactNode;
}) {
  return (
    <label className="block">
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-[13px] font-medium">{label}</span>
        {trailing}
      </div>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        autoComplete={autoComplete}
        className="w-full bg-background border border-border rounded-md px-3 py-2.5 text-[14px] placeholder:text-muted-foreground/70 focus:outline-none focus:border-[var(--brand)] focus:ring-[3px] focus:ring-[color-mix(in_oklab,var(--brand)_18%,transparent)] transition-all"
      />
    </label>
  );
}

function SocialButton({ children }: { children: React.ReactNode }) {
  return (
    <button
      type="button"
      className="w-full flex items-center justify-center gap-2.5 border border-border bg-background rounded-md py-2.5 text-[14px] font-medium hover:bg-secondary transition-colors"
    >
      {children}
    </button>
  );
}

function GoogleMark() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" aria-hidden>
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.99.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z" />
    </svg>
  );
}

function AppleMark() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M16.365 1.43c0 1.14-.493 2.27-1.177 3.08-.744.9-1.99 1.57-2.987 1.49-.12-1.17.44-2.34 1.118-3.08.762-.83 2.05-1.44 3.046-1.49zM21.5 17.36c-.36.84-.53 1.21-.99 1.95-.64 1.03-1.54 2.31-2.66 2.32-1 .01-1.26-.65-2.61-.64-1.35.01-1.64.65-2.64.64-1.12-.01-1.97-1.17-2.61-2.2-1.79-2.87-1.98-6.24-.87-8.03.78-1.27 2.02-2.02 3.18-2.02 1.18 0 1.92.65 2.9.65.95 0 1.53-.65 2.9-.65 1.04 0 2.13.57 2.91 1.55-2.56 1.4-2.14 5.05.49 6.43z" />
    </svg>
  );
}
